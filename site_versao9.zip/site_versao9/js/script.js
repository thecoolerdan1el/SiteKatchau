window.onload = async function (){ // Função anônima - Sem nome 

    var resultado = await fetch("php/produtos.php", {
        method:"GET"
    });

    var dados = await resultado.json();

    for(var i = 0; i < dados.length; i++){
        
        var conteudo = 
        `<div class="card" id="card">
            <div class="card-titulo">
                <h1>${dados[i].nome_produto}
                </h1>
            </div>
            <div>
            <img class="img-card" src="${dados[i].link_imagem}" alt="">
            </div>
            <div class="card-descricao">
                <p>${dados[i].descricao_produto}</p>
            </div>
            <div class="card-preco">
                <p>R$ </p>
                <p>${dados[i].preco_produto} <zp> 
                EM 6x SEM JUROS<p>
                </p>

            </div>

            <div class="card-acao"
                onclick="comprar(${dados[i].id_produto})">COMPRAR
            </div>
        </div>`


        document.getElementById('produtos').innerHTML += conteudo;
    }

}

function comprar(id){
    var dados = new FormData();
    dados.append("id_produto", id);

    fetch("php/comprar.php",{
        method: "POST",
        body: dados
    });
    
    alert("Produto Adicionado ao Carrinho! ")
}