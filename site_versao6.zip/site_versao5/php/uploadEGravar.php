<?php

    $image = $_FILES["image"];
    $nameProduct = $_POST['nameProduct'];
    $priceProduct = $_POST['priceProduct'];
    $descriptionProduct = $_POST['descriptionProduct'];

    $con = mysqli_connect("localhost:3306", "root", "password", "loja_katchau");

    $novo_arquivo = "./upload" . $image["name"];

    $query = "INSERT INTO produto (nome_produto, descricao_produto, preco_produto, link_imagem) VALUES ('$nameProduct', '$descriptionProduct', '$priceProduct', '$novo_arquivo')";

    $erro = false; 
    if (empty($nameProduct) || empty($priceProduct) || empty($descriptionProduct) || strtolower(pathinfo($image["name"], PATHINFO_EXTENSION)) !== "png") {
        echo('Erro, alguns dos campos estão vazios ou a imagem está no formato errado, somente PNG.');
        $erro = true; 
    } else {
        move_uploaded_file($image["tmp_name"], $novo_arquivo);
    }

    if (!$erro) {
        mysqli_query($con, $query);
    }
    
?>