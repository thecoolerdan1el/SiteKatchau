function enviar(){

    var nameProduct = document.getElementById('product_name').value;
    var priceProduct = document.getElementById('price').value;
    var descriptionProduct = document.getElementById('description').value;
    var image = document.getElementById('image').files;


    var dados = new FormData();
    dados.append('nameProduct', nameProduct);
    dados.append('priceProduct', priceProduct);
    dados.append('descriptionProduct');
    dados.append('image', image[0]);

    fetch("../php/upload.php", {
        method: 'POST',
        body: dados
    });
}