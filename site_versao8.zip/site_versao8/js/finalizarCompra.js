async function venda(){

    var form = document.getElementById('formulario');
    var dados = new FormData(form);

    var promise = await fetch("../php/finalizarCompra.php", {
        method: "POST", 
        body: dados
    });

    var resposta = await promise.json();
    alert(resposta);
    
}


