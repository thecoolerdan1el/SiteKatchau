<?php
$select = $_POST["pagamento"];

$mensagem = "";
$imagem = "";

switch ($select) {
    case "pix":
        $mensagem = "Forma de pagamento: PIX - COMPRA EFETUADA COM SUCESSO";
        break;
    case "credito":
        $mensagem = "forma de pagamento: Crédito - COMPRA EFETUADA COM SUCESSO";
        break;
    case "debito":
        $mensagem = "forma de pagamento: Débito - COMPRA EFETUADA COM SUCESSO";
        break;
}
$json = json_encode($mensagem);
echo $json;
?>

