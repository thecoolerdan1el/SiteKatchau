async function excluir(){
    
    var product_id = document.getElementById('product').value;

    var dados =  new FormData();
    dados.append('product_id', product_id);

    product_id = document.getElementById('product').value = "";

    var promise = await fetch("../php/excluir.php", {
        method: 'POST',
        body: dados
    });

    var resposta = await promise.json();
    alert(resposta);
}